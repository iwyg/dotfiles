<?php

echo 'ą';
